<?php
header("Content-Type: application/json");

/* 🔎 DEBUG MODE (TURN OFF IN PRODUCTION) */
error_reporting(E_ALL);
ini_set('display_errors', 1);

include "db.php";

/* ================= RECEIVE DATA ================= */
$farmer_id   = (int)($_POST['farmer_id'] ?? 0);
$category    = trim($_POST['category'] ?? '');
$name        = trim($_POST['name'] ?? '');
$description = trim($_POST['description'] ?? '');
$price       = (float)($_POST['price'] ?? 0);
$unit        = trim($_POST['unit'] ?? '');
$quantity    = (int)($_POST['quantity'] ?? 0);

/* ================= VALIDATION ================= */
if (
    $farmer_id <= 0 ||
    $category === '' ||
    $name === '' ||
    $price <= 0 ||
    $unit === '' ||
    $quantity <= 0
) {
    echo json_encode([
        "success" => false,
        "message" => "All fields are required"
    ]);
    exit;
}

/* ================= GET FARM ID ================= */
$farmStmt = $conn->prepare(
    "SELECT id FROM farms WHERE user_id = ? LIMIT 1"
);

if (!$farmStmt) {
    echo json_encode([
        "success" => false,
        "message" => "Farm query prepare failed"
    ]);
    exit;
}

$farmStmt->bind_param("i", $farmer_id);
$farmStmt->execute();
$farmResult = $farmStmt->get_result();

if ($farmResult->num_rows === 0) {
    echo json_encode([
        "success" => false,
        "message" => "Farm not found for this farmer"
    ]);
    exit;
}

$farm_id = (int)$farmResult->fetch_assoc()['id'];
$farmStmt->close();

/* ================= INSERT PRODUCT ================= */
$insert = $conn->prepare(
    "INSERT INTO products
     (farm_id, category, name, description, price, unit, quantity)
     VALUES (?, ?, ?, ?, ?, ?, ?)"
);

if (!$insert) {
    echo json_encode([
        "success" => false,
        "message" => "Prepare failed: " . $conn->error
    ]);
    exit;
}

$insert->bind_param(
    "isssdsi",
    $farm_id,
    $category,
    $name,
    $description,
    $price,
    $unit,
    $quantity
);

if (!$insert->execute()) {
    echo json_encode([
        "success" => false,
        "message" => "Execute failed: " . $insert->error
    ]);
    exit;
}

$productId = $conn->insert_id;
$insert->close();

/* ================= SUCCESS ================= */
echo json_encode([
    "success"    => true,
    "product_id"=> $productId,
    "message"   => "Product added successfully"
]);
